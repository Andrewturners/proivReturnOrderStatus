'use strict';
var Alexa = require('alexa-sdk');
// Import events module

var APP_ID = undefined; //OPTIONAL: replace with "amzn1.echo-sdk-ams.app.[your-unique-value-here]";
var SKILL_NAME = 'Check Current Orders';
var querystring = require('querystring');
var https = require('https');
var http = require('http');
var host = '54.82.210.173'
var sessionId = null;
var ProivCall = '';
var orderNumber = null;

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
       this.emit(':ask','please tell me the order number you would like me to check','please tell me the order number you would like me to check')
        
    },
    'CheckOrderNumberIntent': function () {
        var query;
        orderNumber = this.event.request.intent.slots.number.value;
         login(query,function(returnvalue){
        console.log("retunred form login" + returnvalue)
        this.emit(':ask', returnvalue, orderNumber);
    }.bind(this))
        
    },
    'FinishedIntent': function () {
        this.emit(':tellWithCard', 'Thank you for using this service to check your orders', SKILL_NAME, 'the checking of orders was completed using PROIV 8.3. For more informatin contact andrew.turner@ngahr.com');
        
    }
    
}
function performRequest(endpoint, method, data, success) {
  var dataString = JSON.stringify(data);
  var headers = {};
  if (method == 'GET') {
    endpoint += '?' + querystring.stringify(data);
  }
  else {
    headers = {
      'Content-Type': 'application/json',
      'Content-Length': dataString.length
    };
  }var options = {
    host: host,
    path: endpoint,
    method: method,
    headers: headers
  };
    var req = http.request(options, function(res) {
    res.setEncoding('utf-8');

    var responseString = '';

    res.on('data', function(data) {
      responseString += data;
    });

    res.on('end', function() {
      console.log('final response',responseString);
      var responseObject = JSON.parse(responseString);
      success(responseObject);
      
    });
  });

  req.write(dataString);
  req.end();
}

function login(query, callback) {

    performRequest('/ordercheck', 'GET', {
        Order: orderNumber
  }, function(data) {
     console.log("returned from ProIV REST call" + data.details);
    ProivCall = data.details;
    callback(ProivCall);
  });
}